using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class disableOnGround : MonoBehaviour
{
    // Update is called once per frame
    void FixedUpdate()
    {
        if (transform.position.y <= 0)
        {
            Destroy(gameObject);
                }
    }
}
