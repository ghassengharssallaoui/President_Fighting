using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class charInfo2
{
    public Text title;
 public Text description;
    public SpriteRenderer headerSprite;
    public SpriteRenderer input1;
    public SpriteRenderer input2;
    public SpriteRenderer input3;
    public SpriteRenderer input4;

    //any other info
}