using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VersionDecider : MonoBehaviour
{
    public bool WebGL;
    public bool mobile;
    public bool camBuild;
    public bool server;
    public bool client;
    public bool host;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }    
}
