using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public class SubOption
{
    public GameObject option;
    public int additionalActionableFrame;
    public bool lockOut;

}
