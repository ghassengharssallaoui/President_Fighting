using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class inputHolderForDestroy : MonoBehaviour
{
    public GameObject[] inputs;

}
