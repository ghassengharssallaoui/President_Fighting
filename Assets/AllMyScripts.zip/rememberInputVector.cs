using UnityEngine;

public class rememberInputVector : MonoBehaviour
{
    public Vector2 vector;

}
