using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class animSound
{
    public AudioClip sfx;
    public string soundID;
    //any other info
}