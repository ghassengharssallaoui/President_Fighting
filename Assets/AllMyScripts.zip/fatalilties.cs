using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fatalilties : MonoBehaviour
{
    public GameObject GunshotGround1;
    public GameObject GunshotGround2;
    // Start is called before the first frame update

}
