using UnityEngine;

public class camIdentifierForOnline : MonoBehaviour
{
    public BetterCameraMovement cam;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
}
