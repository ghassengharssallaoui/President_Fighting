using UnityEngine;

public class playerIdentifierForOnline : MonoBehaviour
{
    public NetworkReceiveInputs[] players = new NetworkReceiveInputs[2];

}
