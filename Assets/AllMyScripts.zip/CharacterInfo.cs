using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterInfo : MonoBehaviour
{
    public charInfo Overview;
    public charInfo Move1;
    public charInfo Move2;
    public charInfo Move3;
    public charInfo Move4;
    public charInfo Move5;
    public charInfo Move6;
    public charInfo Move7;
    public charInfo Move8;
    public charInfo Move9;
    public charInfo Passive1;
    public charInfo Passive2;
    public charInfo Super1;
    public charInfo Super2;
    public charInfo Super3;
    public charInfo Super4;
    public charInfo Super5;
}
