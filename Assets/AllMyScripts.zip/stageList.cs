using UnityEngine;

public class stageList : MonoBehaviour
{
    public GameObject[] list;

}
