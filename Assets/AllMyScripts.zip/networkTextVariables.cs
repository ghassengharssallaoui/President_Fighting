using UnityEngine;
using UnityEngine.UI;

public class networkTextVariables : MonoBehaviour
{
    public Text text;
    int counter;

}
