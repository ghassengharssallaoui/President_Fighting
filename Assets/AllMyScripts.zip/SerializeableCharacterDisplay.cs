using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SerializeableCharacterDisplay
{
    public GameObject state1;
    public GameObject state2;
}
