using UnityEngine;

public class sortingLayerArray : MonoBehaviour
{
    public string[] array;
}
