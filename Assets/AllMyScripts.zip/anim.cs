using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class anim
{
    public int frames;
    public GameObject spriteObject;
    public Sprite sprite;
    public animSound[] sfx;
    public GameObject[] objects;
    //any other info
}